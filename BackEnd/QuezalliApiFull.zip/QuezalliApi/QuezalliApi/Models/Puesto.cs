﻿using System;
using System.Collections.Generic;

namespace QuezalliApi.Models
{
    public partial class Puesto
    {
        public int Idpuesto { get; set; }
        public string NombrePuesto { get; set; } = null!;
    }
}
