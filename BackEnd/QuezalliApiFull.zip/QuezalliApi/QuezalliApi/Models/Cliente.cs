﻿using System;
using System.Collections.Generic;

namespace QuezalliApi.Models
{
    public partial class Cliente
    {
        public int Idcliente { get; set; }
        public int IdPersona { get; set; }
    }
}
