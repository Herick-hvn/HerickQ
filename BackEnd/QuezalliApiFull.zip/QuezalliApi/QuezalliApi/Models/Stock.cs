﻿using System;
using System.Collections.Generic;

namespace QuezalliApi.Models
{
    public partial class Stock
    {
        public int Idstock { get; set; }
        public float CantidadDisonible { get; set; }
    }
}
