﻿using System;
using System.Collections.Generic;

namespace QuezalliApi.Models
{
    public partial class InsumoLote
    {
        public int IdproductoLote { get; set; }
        public int IdInsumo { get; set; }
        public int IdLote { get; set; }
    }
}
