﻿using System;
using System.Collections.Generic;

namespace QuezalliApi.Models
{
    public partial class AvisosInsumo
    {
        public int IdavisosProductos { get; set; }
        public int Idaviso { get; set; }
        public int Idinsumos { get; set; }
    }
}
