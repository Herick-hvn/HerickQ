﻿using System;
using System.Collections.Generic;

namespace QuezalliApi.Models
{
    public partial class ProductoLote
    {
        public int IdproductoLote { get; set; }
        public int IdProducto { get; set; }
        public int IdLote { get; set; }
    }
}
