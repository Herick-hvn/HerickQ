﻿using System;
using System.Collections.Generic;

namespace QuezalliApi.Models
{
    public partial class AvisosProducto
    {
        public int IdavisosProductos { get; set; }
        public int Idaviso { get; set; }
        public int Idproducto { get; set; }
    }
}
