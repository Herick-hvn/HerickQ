﻿namespace QuezalliApi.Models
{
    public class PulseraMaterial
    {
        public int IdPulseraMaterial { get; set; }
        public int IdRecetaPulsera { get; set; }
        public int IdMaterial { get; set; }
        public int Cantidad { get; set; }
    }
}
