﻿using System;
using System.Collections.Generic;

namespace QuezalliApi.Models
{
    public partial class UsersRole
    {
        public int? UserId { get; set; }
        public int? RoleId { get; set; }
    }
}
